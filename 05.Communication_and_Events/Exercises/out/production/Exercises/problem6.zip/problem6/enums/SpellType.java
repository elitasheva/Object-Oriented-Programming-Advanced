package problem6.enums;

public enum SpellType {
    REFLECTION,
    FIREBALL,
}
