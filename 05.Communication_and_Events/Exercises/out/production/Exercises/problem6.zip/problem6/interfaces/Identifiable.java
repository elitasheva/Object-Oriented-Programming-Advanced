package problem6.interfaces;

public interface Identifiable {
    int getId();
}
