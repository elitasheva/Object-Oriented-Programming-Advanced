package problem6.interfaces;

public interface Nameable {
    String getName();
}
