package problem6.interfaces;

public interface Executable {
    void execute(String[] params);
}
