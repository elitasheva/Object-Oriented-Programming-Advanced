package problem6.interfaces;

public interface Listener {
    void update(Spell event);
}
