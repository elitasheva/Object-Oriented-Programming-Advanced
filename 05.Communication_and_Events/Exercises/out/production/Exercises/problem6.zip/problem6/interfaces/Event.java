package problem6.interfaces;

public interface Event {
    Subject getSource();
}
