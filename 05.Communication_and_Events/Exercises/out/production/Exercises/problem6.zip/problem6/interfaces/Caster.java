package problem6.interfaces;

public interface Caster {
    void cast(Spell spell);
    int getPower();
}
