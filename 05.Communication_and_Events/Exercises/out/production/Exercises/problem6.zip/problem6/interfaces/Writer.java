package problem6.interfaces;

public interface Writer {
    void writeLine(String message);
}
