package problem7.interfaces;

public interface ObserverCreator {
    Observer createObserver(String[] params);
}
