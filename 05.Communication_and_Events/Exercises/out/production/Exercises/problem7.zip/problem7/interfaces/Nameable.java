package problem7.interfaces;

public interface Nameable {
    String getName();
}
