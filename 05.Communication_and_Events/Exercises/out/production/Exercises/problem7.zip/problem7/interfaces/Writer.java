package problem7.interfaces;

public interface Writer {

    void writeLine(String message);
}
