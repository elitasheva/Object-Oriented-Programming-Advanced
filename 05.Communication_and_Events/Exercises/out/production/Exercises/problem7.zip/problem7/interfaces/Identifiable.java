package problem7.interfaces;

public interface Identifiable {
    String getId();
}
