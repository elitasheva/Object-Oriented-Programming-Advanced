package problem7.interfaces;

public interface ObservableCreator {
    Observable createObservable(String[] params);
}
