package problem11.models;

import problem11.interfaces.Triplet;

public class TripletImpl<T, U, V> implements Triplet<T, U, V>{

    private T firstParam;
    private U secondParam;
    private V thirdParam;

    public TripletImpl(T firstParam, U secondParam, V thirdParam) {
        this.firstParam = firstParam;
        this.secondParam = secondParam;
        this.thirdParam = thirdParam;
    }

    @Override
    public T getFirstParam() {
        return firstParam;
    }

    @Override
    public U getSecondParam() {
        return secondParam;
    }

    @Override
    public V getThirdParam() {
        return thirdParam;
    }

    @Override
    public String toString() {
        return String.format("%s -> %s -> %s", this.getFirstParam(), this.getSecondParam(), this.getThirdParam());
    }
}
